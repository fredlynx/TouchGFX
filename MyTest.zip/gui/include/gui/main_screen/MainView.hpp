#ifndef MAIN_VIEW_HPP
#define MAIN_VIEW_HPP

#include <gui_generated/main_screen/MainViewBase.hpp>
#include <gui/main_screen/MainPresenter.hpp>
#include <gui/common/BoxWithBorder.hpp>
#include <touchgfx/mixins/ClickListener.hpp>

class MainView : public MainViewBase
{
public:
    MainView();
    virtual ~MainView() {}
    virtual void setupScreen();
    virtual void tearDownScreen();
	void BboxClickedCallbackHandler(const touchgfx::BoxWithBorder& BoxWithBorder, const  touchgfx::ClickEvent& clickEvent);

protected:
	touchgfx::Callback< MainView, const touchgfx::BoxWithBorder&, const touchgfx::ClickEvent& > BboxClickActionCallback;

	touchgfx::ClickListener< touchgfx::BoxWithBorder > Bbox;
};

#endif // MAIN_VIEW_HPP

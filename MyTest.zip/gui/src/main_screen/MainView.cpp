#include <gui/main_screen/MainView.hpp>
#include <touchgfx/Color.hpp>

MainView::MainView() :
	BboxClickActionCallback(this, &MainView::BboxClickedCallbackHandler)
{

}

void MainView::setupScreen()
{
	Bbox.setPosition(10, 10, 300, 48);
	Bbox.setBorder(1);
	Bbox.setBorderColor(touchgfx::Color::getColorFrom24BitRGB(255, 255, 255));
	Bbox.setEndColor(touchgfx::Color::getColorFrom24BitRGB(2, 121, 180));
	Bbox.setColor(touchgfx::Color::getColorFrom24BitRGB(3, 74, 114));
	Bbox.setFillMode(BoxWithBorder::GRADIENT_H);
	Bbox.setAlpha(255);
	Bbox.setClickAction(BboxClickActionCallback);
	add(Bbox);
}

void MainView::tearDownScreen()
{

}

void MainView::BboxClickedCallbackHandler(const touchgfx::BoxWithBorder& BoxWithBorder, const  touchgfx::ClickEvent& clickEvent)
{
	if (clickEvent.getType() == clickEvent.RELEASED)
	{
		Box.setColor(9852);
		Box.invalidate();
	}
}